import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star, Heart, Sun, Smile } from 'lucide-react';

const Home: React.FC = () => {
    return (
        <div className="flex flex-col min-h-screen">
            {/* Hero Section */}
            <section className="relative min-h-[600px] flex items-center bg-primary overflow-hidden">
                <div className="absolute inset-0 z-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1544367563-12123d8965cd?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center"></div>
                <div className="absolute inset-0 bg-gradient-to-r from-primary to-primaryDark opacity-90 z-0"></div>
                
                <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                        <div className="text-white space-y-8">
                            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight font-serif">
                                나를 위한 시간,<br />
                                <span className="text-secondary">집에서 시작하는</span><br />
                                건강한 하루
                            </h1>
                            <p className="text-lg sm:text-xl lg:text-2xl leading-relaxed text-gray-100">
                                50대 이후, 우리 몸은 더 세심한 관심이 필요합니다.<br />
                                매일 15분, 쉽고 편안한 홈케어로 활력 있는 일상을 되찾으세요.
                            </p>
                            <div className="flex flex-col sm:flex-row gap-4 pt-4">
                                <Link to="/routine" className="inline-flex items-center justify-center bg-accent text-white px-8 py-4 rounded-full text-xl font-bold hover:bg-opacity-90 transition transform hover:scale-105 shadow-lg">
                                    무료 건강 루틴 받기
                                    <ArrowRight className="ml-2 w-5 h-5" />
                                </Link>
                                <Link to="/chat" className="inline-flex items-center justify-center bg-white text-primary px-8 py-4 rounded-full text-xl font-bold hover:bg-secondary transition transform hover:scale-105 shadow-lg">
                                    AI 상담사와 대화하기
                                </Link>
                            </div>
                            <div className="flex flex-wrap gap-8 pt-8 border-t border-white border-opacity-30">
                                <div className="flex items-center space-x-2">
                                    <Star className="text-secondary w-6 h-6 fill-current" />
                                    <div>
                                        <p className="text-xl font-bold">12,000+</p>
                                        <p className="text-sm text-gray-200">만족한 회원</p>
                                    </div>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <Heart className="text-secondary w-6 h-6 fill-current" />
                                    <div>
                                        <p className="text-xl font-bold">98%</p>
                                        <p className="text-sm text-gray-200">추천 의향</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="hidden lg:block">
                            <div className="bg-white rounded-3xl p-6 shadow-2xl transform rotate-2 hover:rotate-0 transition duration-500">
                                <img 
                                    src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=2070&auto=format&fit=crop" 
                                    alt="Senior Wellness" 
                                    className="rounded-2xl w-full h-80 object-cover mb-6"
                                />
                                <div className="text-center">
                                    <p className="text-gray-600 text-lg italic font-serif">
                                        "매일 아침 루틴으로 하루가 달라졌어요."
                                    </p>
                                    <p className="text-primary font-bold mt-2">- 김영자 님, 67세</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Features Section */}
            <section className="py-20 bg-white">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4 font-serif">
                            당신의 건강 파트너
                        </h2>
                        <p className="text-xl text-gray-600">
                            시니어를 위해 특별히 설계된 웰니스 솔루션
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <div className="bg-offWhite rounded-3xl p-8 hover:shadow-xl transition duration-300 border border-gray-100">
                            <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mb-6 mx-auto">
                                <Sun className="w-8 h-8 text-primary" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 mb-3 text-center font-serif">AI 맞춤 루틴</h3>
                            <p className="text-gray-600 text-center text-lg">
                                그날의 컨디션에 따라<br/>가장 적합한 운동과 휴식을<br/>제안해 드립니다.
                            </p>
                        </div>
                        
                        <div className="bg-offWhite rounded-3xl p-8 hover:shadow-xl transition duration-300 border border-gray-100">
                            <div className="w-16 h-16 bg-accent bg-opacity-10 rounded-full flex items-center justify-center mb-6 mx-auto">
                                <Heart className="w-8 h-8 text-accent" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 mb-3 text-center font-serif">자연 치유법</h3>
                            <p className="text-gray-600 text-center text-lg">
                                약에 의존하기보다<br/>자연의 힘으로 몸을<br/>다스리는 법을 배웁니다.
                            </p>
                        </div>

                        <div className="bg-offWhite rounded-3xl p-8 hover:shadow-xl transition duration-300 border border-gray-100">
                            <div className="w-16 h-16 bg-secondary bg-opacity-50 rounded-full flex items-center justify-center mb-6 mx-auto">
                                <Smile className="w-8 h-8 text-gray-800" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 mb-3 text-center font-serif">친절한 상담</h3>
                            <p className="text-gray-600 text-center text-lg">
                                궁금한 점이 있다면<br/>언제든 AI 상담사에게<br/>물어보세요.
                            </p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Home;